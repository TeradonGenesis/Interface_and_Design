function reason() {
	var reason = prompt("Reason:);
	return reason;
}