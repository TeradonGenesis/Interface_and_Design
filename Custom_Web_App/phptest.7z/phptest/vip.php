<!DOCTYPe html>

<html lang="en">
<?php
include"header.php"; 
?>

<head>
<?php
	head(); 
?>
<title>Project Buy</title>
</head>
<body>
<?php
nav(); 
?>

<p><a href="member_add_form.php"><button type="button"/>Add Member</button></a></p>
<p><a href="member_display.php"><button type="button"/>Display Member</button></a></p>
<p><a href="member_search.php"><button type="button"/>Search Member</button></a></p>
<p><a href="member_login.php"><button type="button"/>Member Login</button></a></p>
</body>
</html>